/**
 *
 *  @author Stanczewski Patryk S22901
 *
 */

package zad1;


public interface Mapper<T, S>
{
    public S map (T element);
}
