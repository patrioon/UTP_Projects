/**
 *
 *  @author Stanczewski Patryk S22901
 *
 */

package zad1;


public interface Selector<T>{

    public boolean select (T element);
}
